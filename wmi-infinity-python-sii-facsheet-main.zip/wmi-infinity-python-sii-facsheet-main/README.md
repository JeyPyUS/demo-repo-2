# wmi-infinity-python-sii-facsheet
Data extraction from SII to Infinity for factsheets
