import zipfile
import datetime
import os
import shutil
import sys

def backup_envs(folder_path):
    timestamp = datetime.datetime.now().strftime("environments-%Y%m%d%H%M%S")  # Generate current timestamp
    zip_filename = f"{timestamp}.zip"  # Create the zip file name with the timestamp
    parent_dir = os.path.dirname(folder_path)  # Get the parent directory path
    zip_filepath = os.path.join(parent_dir, zip_filename)  # Path to the zip file

    with zipfile.ZipFile(zip_filepath, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, folder_path))

    print(f"Folder {folder_path} has been zipped as {zip_filepath}")


def get_folders(path):
    os.chdir(path)
    print(f"Working dir {os.getcwd()}")

    paths = []
    for dir in os.listdir(os.getcwd()):
        item = os.path.join(os.getcwd(), dir)
        if os.path.isdir(item):
            paths.append(item)
    return paths


def configure_environments(pipeline_envs):
    for e in pipeline_envs:
        env_arg = sys.argv[1]
        candidate_env = e.replace("\\venvs_config\\", "\\")
        name_env = os.path.split(candidate_env)[1]

        if env_arg != name_env:
            continue
        _, env_name = os.path.split(candidate_env)
        if not os.path.isdir(candidate_env):
            os.system(f"virtualenv {env_name}")


        shutil.copy(os.path.join(e, "requirements.in"), candidate_env)
        cwd = os.getcwd()
        os.chdir(candidate_env)

        requirements = os.path.join(candidate_env, 'requirements.in')
        print("requirements in file", requirements)
        print("current dir", os.getcwd())
        print(f"Actualizando dependencias en {candidate_env}")
        python_bin = os.path.join(candidate_env, "Scripts\\python.exe")
        try:
            os.system(f"{python_bin} -m pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org --proxy http://proxy.sig.umbrella.com:443 pip-tools")
            print("Compilando dependencias...")
            os.system(f"{python_bin} -m piptools compile --pip-args \"--trusted-host pypi.org --trusted-host files.pythonhosted.org --proxy http://proxy.sig.umbrella.com:443\"")
            print("Sincronizando dependencias...")
            os.system(f"{python_bin} -m piptools sync --pip-args \"--trusted-host pypi.org --trusted-host files.pythonhosted.org --proxy http://proxy.sig.umbrella.com:443\"")
        except Exception:
            raise ValueError("ERROR: ha habido un problema al sincornizar las dependencias!")
        os.chdir(cwd)


# pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org --proxy http://proxy.sig.umbrella.com:443 -r requirements.txt
def main():
   folder_to_zip = 'D:\\Workspace\\Environments'
   # backup_envs(folder_to_zip)
   pipeline_envs = get_folders(".")
   current_envs = get_folders("..")
   configure_environments(pipeline_envs)



if __name__ == "__main__":
    main()
