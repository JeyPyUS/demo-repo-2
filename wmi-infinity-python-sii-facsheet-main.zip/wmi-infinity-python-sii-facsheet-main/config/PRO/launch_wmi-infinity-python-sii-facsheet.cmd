﻿@ECHO ON
TITLE Execute python script
ECHO Please Wait...

:: Section 1: Activate the environment (wmi-infinity-python-sii-facsheet_env).
ECHO ============================
ECHO Activating my python environment folder...
ECHO ============================

:: TODO
@CALL "D:\Workspace\Environments\wmi-infinity-python-sii-facsheet_env\Scripts\activate.bat"

:: Section 2: Execute python script.
ECHO ============================
ECHO Running wmi-infinity-python-sii-facsheet
ECHO ============================

cd "D:\Workspace\Python"
python -m wmi-infinity-python-sii-facsheet.main

ECHO ============================
ECHO End
ECHO ============================