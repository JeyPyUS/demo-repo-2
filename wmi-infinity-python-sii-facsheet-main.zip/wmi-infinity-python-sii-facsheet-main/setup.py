from setuptools import setup

setup(
        name="wmi-infinity-python-sii-facsheet",
	    version="0.0.1",
	    author="Antonio Bri",
		author_email="antonio.briperez@servexternosgruposantander.com",
		description="Data extraction from SII to Infinity for factsheets",
		long_description=open('README.md').read(),
		url="https://github.com/santander-group-wealth-ng/wmi-infinity-python-sii-facsheet.git",
		classifiers=[
			        "Programming Language :: Python :: 3",
			        "License :: OSI Approved :: MIT License",
			        "Operating System :: OS Independent",
				    ],
		py_modules=[],       
    )
