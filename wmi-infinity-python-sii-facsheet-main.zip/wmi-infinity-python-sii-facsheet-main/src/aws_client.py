"""
AWS client
----------------------
Module for connecting to INFINITY S3 buckets.

Example usage:
    from aws_client import AWSClient
    # 1. Create AWS client instance
    db_client = AWSClient(my_logger)
    # 2. Configure AWS connection
    db_client.setup(my_config, my_monitor)
    db_client.get_aws_session()
    # 3. Perform any database operation
    db_client.send_df_to_s3(my_df, my_queryname)

Authors:
    - Juan Pablo Urrutia
"""

import os
import io
import sys
from logging import Logger
import pandas as pd
from datetime import datetime
from pandas import DataFrame
import boto3

# Librerias propias de Common
import Common.Libs.s3_utils as s3_utils

# Formato de fechas para la generación de los ficheros
DATE_FORMAT_FILENAME = '%d%m%Y'
# Formato de fechas para el contenido de los CSV
DATE_FORMAT_CSV = '%d/%m/%Y'

class AWSClient(object):
    """Class for AWS interaction.
    """

    def __init__(self, logger: Logger) -> None:
        """Initialize class attributes with default values.

        Args:
            logger (Logger): Configured logger.
        """
        self.logger = logger
        self.s3_bucket = ''
        self.processed_folder = ''


    def setup(self, config: dict, monitor) -> None:
        """Store the AWS parameters in their corresponding
        class attributes.

        Args:
            config (dict): Contains the AWS parameters inside
                a section called `aws_s3`. Can be obtained from
                the project configuration file (for example, config.ini).
        """
        aws_config = config['aws_s3']
        self.s3_bucket = aws_config["aws_s3_bucket"]
        self.processed_folder = aws_config["aws_s3_prefix_output"]

        if aws_config['env'] == 'local':
            self.session = self.get_aws_session()
            self.session.client("s3", verify=False)
        else:
            boto3.client("s3")

        self.files_date = config['files_date']
        self.exec_monitor = monitor


    def get_aws_session(self):
        """
        Método encargado de crear la conexión a AWS para su utilización en local
        """
        session = boto3.session.Session()
        profile_name = os.getenv("PROFILE_NAME", "")
        boto3.setup_default_session(profile_name=profile_name)
        if profile_name:
            session = boto3.session.Session(profile_name=profile_name)
        return session


    def send_df_to_s3(self, df, query_name):
        """
            Método encargado de subir los fihceros a S3

            Args:
                df (DataFrame): DF with de data.
                query_name (str): File name.
        """
        # # Pasamos el DF por una función para formatear varias columnas
        # df = format_values_df(df)

        file_name = f"{query_name}_{self.files_date}.csv"

        # Crear fichero csv a partir del DataFrame
        csv_file = io.BytesIO()
        df.to_csv(csv_file, sep=';', decimal='.', index=False, date_format=DATE_FORMAT_CSV)
        csv_file.seek(0)

        self.logger.info(f'Fichero {file_name} generado correctamente.')

        # Envio de fichero a S3
        sent_flg = s3_utils.upload_to_s3(self.s3_bucket, csv_file, True, file_name, prefix=self.processed_folder)

        if sent_flg:
            self.logger.info(f"Fichero {file_name} subido correctamente a bucket de S3 con {df.shape[0]} registros.")
            self.exec_monitor.add_observation(f'<{query_name} [OK]>')
            return True
        else:
            self.logger.info(f"El fichero {file_name} no se ha subido a bucket de S3.")
            self.exec_monitor.add_observation(f'<{query_name} [KO]>')
            return False
