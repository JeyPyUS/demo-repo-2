"""
Aurora datamart client
----------------------
Module for connecting to INFINITY Aurora Datamart and performing
data insertions and reads on it using SQLAlchemy.

Example usage:
    from aurora_client import AuroraClient
    # 1. Create Aurora client instance
    db_client = AuroraClient(my_logger, 'dev')
    # 2. Configure database connection and tables
    db_client.setup_database('aurora_datamarts_')
    db_client.setup_tables(my_config)
    # 3. Perform any database operation
    db_client.upload_to_datamart(my_df, my_date)

Authors:
    - Marta Villalba Cantero (marta.villalbacantero@servexternos.gruposantander.com).
"""

from logging import Logger
from pandas import DataFrame
from Common.DB.database_client import DatabaseClient


class AuroraClient(DatabaseClient):
    """Class for Aurora database interaction.
    """
    def __init__(self, logger: Logger, env: str) -> None:
        """
            Initialize class attributes with default values.

            Args:
                logger (Logger): Configured logger.
                env (str): Environment where the code is being executed.
        """
        super().__init__(logger, env)
        self.dtm = ''

    def setup_tables(self, config: dict) -> None:
        """
            Store the Aurora datamart database and tables names in
            their corresponding class attributes.

            Args:
                config (dict): Contains the name of the schemas and tables
                    inside a section called `aurora_datamart`. Can be obtained from
                    the project configuration file (for example, config.ini).
        """
        aurora_config = config['aurora_db']
        self.dtm = aurora_config['schema_dtm']

