"""
Redshift data warehouse client
------------------------------
Module for connecting to INFINITY Redshift DWH and performing
data insertions and reads on it using SQLAlchemy.

Example usage:
    from redshift_client import RedshiftClient
    # 1. Create Redshift client instance
    db_client = RedshiftClient(my_logger, 'dev')
    # 2. Configure database connection and tables
    db_client.setup_database('redshift_infinity_')
    db_client.setup_tables(my_config)

Authors:
    - Marta Villalba Cantero (marta.villalbacantero@servexternos.gruposantander.com).
"""

from datetime import datetime
from logging import Logger
from Common.DB.database_client import DatabaseClient

class RedshiftClient(DatabaseClient):
    """
        Class for Aurora database interaction.
    """
    def __init__(self, logger: Logger, env: str) -> None:
        """
            Initialize class attributes with default values.

            Args:
                logger (Logger): Configured logger.
                env (str): Environment where the code is being executed.
        """
        super().__init__(logger, env)
        self.dwh = ''
        self.dwh_table_performance_index = ''
        self.dwh_table_ter = ''

    def setup_tables(self, config:dict) -> None:
        """
            Configure main values for the RedshiftClient object

            Args:
                config (dict): Dict with config.ini iKT.
        """
        redshift_config = config['redshift_db']
        self.dwh = redshift_config['schema_dwh']
        self.dwh_table_performance_index = redshift_config['table_performanceindex']
        self.dwh_table_ter = redshift_config['table_ter']
