"""
Main
----------------------
Main module for execute SII Extraction project.

Authors:
    - Juan Pablo Urrutia
"""

import calendar
import boto3
import dateutil
import pandas as pd
import datetime
import os
from os.path import basename
import sys
from .sii_extraction import SiiExtraction


# Nivel de LOG por defecto si no se proporciona ninguno en los parametros de ejecucion del script
DEFAULT_LOG_LEVEL = 'INFO'
# Nivel de LOG por defecto si no se proporciona ninguno en los parametros de ejecucion del script
DEFAULT_ENVIRONMENT = 'development_LZ'
# Nombre del repositorio
REPOSITORY_NAME = 'wmi-infinity-python-sii-facsheet'
# Nombre del proyecto
PROJECT_NAME = 'SII Factsheet'
# Formato de la fecha que llega por parámetro
DATE_FORTMAT_ORIGIN = '%Y-%m-%d'
# Valor por defecto de la fecha de generación de los ficheros
DEFAULT_DATE = 'Today'
# Nombres de ficheros SQL más usados
QUERY_FILE = 'queries.sql'
# Ruta del directorio del proyecto
PROJECT_PATH = os.path.abspath(os.path.dirname(__file__))
# Ruta del directorio de las consultas
SQL_PATH = os.path.join(PROJECT_PATH, 'sql')


COMMON_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'Common'))
sys.path.insert(0, COMMON_PATH)

from Common.Libs.logger_configuration import setup_logger


def main():

    timestamp = datetime.datetime.now()

    # Configuración del Log
    log_path = os.path.join(COMMON_PATH, 'Logs')
    log_file = log_path.replace('\\','/')
    log_file = f"{log_file}/{REPOSITORY_NAME}_{timestamp}.txt"
    logger = setup_logger(DEFAULT_LOG_LEVEL, timestamp, PROJECT_NAME, REPOSITORY_NAME, log_path)

    # Datos de conexión
    config_file = os.path.join(os.path.dirname(__file__), 'config.ini')

    extraccion = SiiExtraction(PROJECT_NAME, logger, timestamp)
    extraccion.setup(config_file)
    extraccion.run()


if __name__ == "__main__":
    main()
