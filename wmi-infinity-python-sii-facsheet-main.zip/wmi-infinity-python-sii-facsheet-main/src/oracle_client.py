"""
Oracle client
----------------------
Module for connecting to SII oracle and performing
data insertions and reads on it using SQLAlchemy.

Example usage:
    from oracle_client import OracleClient
    # 1. Create Oracle client instance
    db_client = OracleClient(my_logger, 'dev')
    # 2. Configure database connection and tables
    db_client.setup_database(my_config)
    db_client.setup_tables(my_config)
    # 3. Perform any database operation
    db_client.get_df(my_query)

Authors:
    - Juan Pablo Urrutia
"""

from logging import Logger
from sqlalchemy import create_engine
import os
import sys
import oracledb
import pandas as pd

class OracleClient(object):
    """Class for Redshift database interaction.
    """

    def __init__(self, logger: Logger, env: str):
        """Initialize class attributes with default values.

        Args:
            logger (Logger): Configured logger for the MSCI ETL process.
            env (str): Environment where the ETL process is being executed.
        """
        self.siif_table = ''
        self.logger = logger
        self.engine = None
        self.connection = None


    def setup_database(self, config: dict):
        """
            Set connection to database

            Args:
                config (dict): Contains the name of the schemas and tables
                    inside a section called `redshift_infinity`. Can be obtained
                    from the project configuration file (for example, config.ini).
        """

        oracle_db = config['oracle_db']

        conn_string = f"{oracle_db['db_user']}/{oracle_db['db_pass']}@{oracle_db['db_server']}:{oracle_db['db_port']}/{oracle_db['db_name']}"

        # Crear la conexión
        self.connection = oracledb.connect(conn_string)


    def get_df(self, query: str):

        df = pd.read_sql(query, self.connection)

        return df
