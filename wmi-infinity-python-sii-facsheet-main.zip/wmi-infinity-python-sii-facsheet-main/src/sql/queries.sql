-- performance_index
SELECT
  '{id}' as "cod_index",
  FHFECALT as "dat_fact",
  IMVALIND as "per_returnday"
FROM
  T0VAVIND
WHERE
  CDCODIND = '{siiCode}'
  AND MCTOTRET = '{tot}'
  AND FHFECALT >= TO_DATE('{sStartDate}','DD-MM-YYYY')
ORDER BY FHFECALT ASC

-- TER_data
SELECT
  CDTIPCON as "cod_fundcont",
  CDCODFON as "cod_fundsii",
  FHFECHAX as "dat_fact",
  PCGASTOT + PCGASSIN as "imp_ter"
FROM
  T0TRECOM
WHERE
  FHFECHAX = TO_DATE('{dDate}','DD-MM-YYYY')
  AND MCTRIANU = 'A'
