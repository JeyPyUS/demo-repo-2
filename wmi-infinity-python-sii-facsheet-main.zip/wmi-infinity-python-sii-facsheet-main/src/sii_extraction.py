"""
Aurora datamart client
----------------------
Module for connecting to INFINITY Aurora Datamart and performing
data insertions and reads on it using SQLAlchemy.

Example usage:
    from aurora_client import AuroraClient
    # 1. Create Aurora client instance
    db_client = AuroraClient(my_logger, 'dev')
    # 2. Configure database connection and tables
    db_client.setup_database('aurora_datamarts_')
    db_client.setup_tables(my_config)
    # 3. Perform any database operation
    db_client.upload_to_datamart(my_df, my_date)

Authors:
    - Marta Villalba Cantero (marta.villalbacantero@servexternos.gruposantander.com).
"""

import calendar
import os
import sys
import logging
import logging.config
from time import time
import datetime as dt
from datetime import datetime
from dateutil.relativedelta import relativedelta
from traceback import format_exc
from logging import Logger, FileHandler
from warnings import filterwarnings

import pandas as pd



# Formato de fechas para la generación de los ficheros
DATE_FORMAT_FILENAME = '%d%m%Y'
# Formato de fecha
DATE_FORMATING = '%Y-%m-%d'
# Formato de fecha Oracle
DATE_FORMATING_OCL = '%d-%m-%Y'
# Ruta del directorio del proyecto
PROJECT_PATH = os.path.abspath(os.path.dirname(__file__))
# Ruta del directorio de las consultas
SQL_PATH = os.path.join(PROJECT_PATH, 'sql')

COMMON_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'Common'))
sys.path.insert(0, COMMON_PATH)

from Common.DB.db_executions import ExecutionMonitor
from Common.Config.config import read
from Common.DB.database_client import DatabaseClient
from Common.Libs.s3_utils import upload_to_s3

from .aws_client import AWSClient
from .aurora_client import AuroraClient
from .oracle_client import OracleClient
from .redshift_client import RedshiftClient

class SiiExtraction(object):

  def __init__(
      self,
      project_name: str,
      logger: Logger,
      init: datetime) -> None:

    self.logger = logger

    self.log_path = ''
    self.aws = None
    self.config = {}
    self.project_name = project_name
    self.exec_monitor = None
    self.init_timestamp = init
    self.queries = {}


  def setup(self, config_file: str):
    files_date = dt.date.today().strftime(DATE_FORMAT_FILENAME)
    # Literals and other custom configurations
    self.config = read(config_file)
    self.config['files_date'] = files_date
    # Queries in queries.sql
    self.queries = self.read_sql_file()
    # Execution environment
    self.env = self.config['env']['env']
    # Redshidt datamart client
    self.redshift = RedshiftClient(self.logger, self.env)
    self.redshift.setup_database('redshift_infinity_')
    self.redshift.setup_tables(self.config)
    # Oracle client
    self.oracle = OracleClient(self.logger, self.env)
    self.oracle.setup_database(self.config)
    # Aurora datamart client
    self.aurora = AuroraClient(self.logger, self.env)
    self.aurora.setup_database('aurora_datamarts_')
    self.aurora.setup_tables(self.config)
    # Project monitorization
    self.exec_monitor = ExecutionMonitor(self.redshift.engine, self.aurora.engine, self.aurora.dtm, self.project_name)
    self.exec_monitor.init_execution(self.init_timestamp, self.log_path)
    # AWS client
    self.aws = AWSClient(self.logger)
    self.aws.setup(self.config, self.exec_monitor)


  def read_sql_file(self):
    """
    This Python function reads SQL queries from a file and returns them as separate blocks.
    :return: The function `leer_archivos` is returning the list `query_blocks`, which contains the
    query blocks extracted from the SQL file specified by `self.sql.sql_queries`.
    """

    dict_queries = {}

    with open(os.path.join(SQL_PATH,'queries.sql'), 'r') as file:
      sql_content = file.read()
      query_blocks = sql_content.split('--')[1:]

    for block in query_blocks:
      query_lines = block.strip().split('\n')
      query_name = query_lines[0].strip()
      sql_query = ' '.join(query_lines[1:])

      dict_queries[query_name] = sql_query

    return dict_queries


  def get_ter_data(self, date):
    """
      Método encargado de recoger los datos del TER de la bbdd de SII

      Args:
        date (datetime): Último día hábil del año anterior.
    """

    query = self.queries['TER_data']

    query = query.replace('{dDate}', date)

    df_ter_data = self.oracle.get_df(query)

    df_ter_data['dat_insertion'] = dt.datetime.now()

    return df_ter_data


  def get_performance_index(self, start_date):
    """
      Método encargado de recoger los datos de performance index de la bbdd de SII

      Args:
        start_date (datetime): Último día hábil del mes anterior al cálculo de Data Factsheets.
                                O lo que es lo mismo, 2 meses antes de la fecha actual.
    """

    # DataFrame para ingestar en dwh_sam_prf_tb_dd_fac_performanceindex
    df_performance_index = pd.DataFrame()

    # Configuración de diccionario con la información en config.ini
    self.config['sii_index']['siicode'] = self.config['sii_index']['siicode'].split(', ')
    self.config['sii_index']['tot'] = self.config['sii_index']['tot'].split(', ')
    self.config['sii_index']['id'] = self.config['sii_index']['id'].split(', ')

    df_sii_index = pd.DataFrame(self.config['sii_index'])

    # Bucle que recorre el df sii_index para generar la query correspondiente
    for row in df_sii_index.itertuples():
      query_row = self.queries['performance_index']
      query_row = query_row.replace('{id}', row.id)
      query_row = query_row.replace('{siiCode}', row.siicode)
      query_row = query_row.replace('{tot}', row.tot)
      query_row = query_row.replace('{sStartDate}', start_date)
      query_row = query_row.replace(';', '')

      # Se recoge el df con los parámetros correspondientes
      df_row = self.oracle.get_df(query_row)

      # Se concatena con el df principal
      df_performance_index = pd.concat([df_performance_index, df_row], ignore_index=True)

    # Se añade la columna 'dat_insertion'
    df_performance_index['dat_insertion'] = dt.datetime.now()

    return df_performance_index


  def get_date_of_data_posglo(self, df_max_date, date_of_data):
    """
      Método auxiliar para determinar la fecha para la recogida de los datos de cartera.

      Args:
        df_max_date (DataFrame): DataFrame con la fecha máxima encontrada en la tabla de Global Position.
        date_of_data (datetime): Último día hábil del mes anterior.
    """

    msg_warn_no_date = 'Parece que no existen datos de cartera para el cierre del mes ' +\
                f'{date_of_data.strftime("%Y-%m")}, por lo que los datos de distribuciones llegarán vacíos.'

    res_date = date_of_data

    if not df_max_date.empty:
      max_date = df_max_date['max_date'].iloc[0]
      if max_date:
        res_date = max_date
      else:
        self.logger.warning(msg_warn_no_date)
    else:
      self.logger.warning(msg_warn_no_date)

    if date_of_data > res_date:
      self.logger.warning(f'La fecha que se tendrá en cuenta para la obtención de los datos de cartera será : {res_date}')

    return res_date


  def get_last_days(self, year: bool = False):
    """
      Método auxiliar para determinar la fecha para la recogida de los datos de SII.

      Args:
        year (boolean): Bandera que determina qué cálculo hacer para la fecha necesitada.
    """

    if year:
      time_data = dt.date.today().replace(day=1) - relativedelta(years=1) - relativedelta(month=12)
    else:
      time_data = dt.date.today().replace(day=1) - relativedelta(months=2)

    # Calculamos el ultimo dia habil del mes especificado
    last_day_of_month = time_data.replace(day=calendar.monthrange(time_data.year, time_data.month)[1])

    return last_day_of_month


  def run(self):

    self.exec_monitor.update_execution_state('Running')

    try:

      starttime = time()

      # Cálculo de fechas para obtención de datos
      date_last_day_of_month = self.get_last_days()
      date_last_day_of_year = self.get_last_days(year=True)

      self.logger.info(f"Último día del mes(actual-2) anterior -> {date_last_day_of_month}")
      self.logger.info(f"Último día del año anterior -> {date_last_day_of_year}")

      filterwarnings("ignore", category=UserWarning, message='.*pandas only supports SQLAlchemy connectable.*')

      df_performance_index = self.get_performance_index(date_last_day_of_month.strftime(DATE_FORMATING_OCL))
      df_ter = self.get_ter_data(date_last_day_of_year.strftime(DATE_FORMATING_OCL))

      self.aws.send_df_to_s3(df_performance_index, 'performance_index')
      self.aws.send_df_to_s3(df_ter, 'TER_data')

      self.redshift.insert_dataframe(df_to_insert=df_performance_index,
                                     schema=self.redshift.dwh,
                                     table=self.redshift.dwh_table_performance_index)

      self.redshift.insert_dataframe(df_to_insert=df_ter,
                                     schema=self.redshift.dwh,
                                     table=self.redshift.dwh_table_ter)

      self.exec_monitor.update_execution_state('Successful')

    except KeyboardInterrupt:
      observation = 'Execution cancelled by user.'
      self.logger.error(observation)
      self.exec_monitor.add_observation(observation)
      self.exec_monitor.update_execution_state('Cancelled')

    except Exception:
      error_traceback = format_exc()
      self.logger.error(error_traceback)
      self.exec_monitor.log_execution_error(error_traceback)

    finally:
      self.redshift.close_connection()
      self.redshift.close_session()
      self.logger.info(f'Script finalizado correctamente en {time()-starttime} segundos')
      self.exec_monitor.end_execution()
