import datetime
import pandas as pd

from src.sii_extraction import SiiExtraction
from utils import mock_common_module
mock_common_module()

mock_dict = {
  'aws_s3_bucket': 'aws_s3_bucket',
  'aws_s3_prefix_output': 'aws_s3_prefix_output'
}

mock_dict_sii_index = {
  'siicode': 'ESTRON085, USRG1Z, LBP0',
  'tot': 'N, N, S',
  'id': '1, 2, 3'
}

mock_config_dict = {
  'aws_s3': mock_dict,
  'files_date': 'files_date',
  'sii_index': mock_dict_sii_index,
  'env': {'env': 'test'}
}

def test_setup(mocker):
  mock_sii_ext = SiiExtraction('project_name', mocker.Mock(), datetime.datetime.now())

  mocker.patch('src.sii_extraction.read', return_value=mock_config_dict)
  mock_redshift = mocker.patch('src.sii_extraction.RedshiftClient')
  mock_redshift.return_value.setup_database = mocker.Mock()
  mock_oracle = mocker.patch('src.sii_extraction.OracleClient')
  mock_oracle.return_value.setup_database = mocker.Mock()
  mock_aurora = mocker.patch('src.sii_extraction.AuroraClient')
  mock_aurora.return_value.setup_database = mocker.Mock()
  mock_monitor = mocker.patch('src.sii_extraction.ExecutionMonitor')
  mock_monitor.return_value.init_execution = mocker.Mock()
  mock_aws = mocker.patch('src.sii_extraction.AWSClient')
  mock_aws.return_value.setup = mocker.Mock()

  mock_sii_ext.setup(mock_config_dict)

  mock_aws.assert_called_once()


def test_read_sql_file(mocker):

  mock_sii_ext = SiiExtraction('project_name', mocker.Mock(), datetime.datetime.now())

  dict_result = mock_sii_ext.read_sql_file()

  assert dict_result


def test_get_performance_index(mocker):

  mock_sii_ext = SiiExtraction('project_name', mocker.Mock(), datetime.datetime.now())

  mock_df = pd.DataFrame({'a': [123]})

  mocker.patch('src.sii_extraction.read', return_value=mock_config_dict)
  mock_redshift = mocker.patch('src.sii_extraction.RedshiftClient')
  mock_redshift.return_value.setup_database = mocker.Mock()
  mock_oracle = mocker.patch('src.sii_extraction.OracleClient')
  mock_oracle.return_value.setup_database = mocker.Mock()
  mock_oracle.return_value.get_df.return_value = mock_df
  mock_aurora = mocker.patch('src.sii_extraction.AuroraClient')
  mock_aurora.return_value.setup_database = mocker.Mock()
  mock_monitor = mocker.patch('src.sii_extraction.ExecutionMonitor')
  mock_monitor.return_value.init_execution = mocker.Mock()
  mock_aws = mocker.patch('src.sii_extraction.AWSClient')
  mock_aws.return_value.setup = mocker.Mock()

  mock_sii_ext.setup('config_file')

  df_result = mock_sii_ext.get_performance_index('01-2025')

  assert len(df_result) == 3


def test_get_ter_data(mocker):

  mock_sii_ext = SiiExtraction('project_name', mocker.Mock(), datetime.datetime.now())

  mock_df = pd.DataFrame({'a': [123]})

  mocker.patch('src.sii_extraction.read', return_value=mock_config_dict)
  mock_redshift = mocker.patch('src.sii_extraction.RedshiftClient')
  mock_redshift.return_value.setup_database = mocker.Mock()
  mock_oracle = mocker.patch('src.sii_extraction.OracleClient')
  mock_oracle.return_value.setup_database = mocker.Mock()
  mock_oracle.return_value.get_df.return_value = mock_df
  mock_aurora = mocker.patch('src.sii_extraction.AuroraClient')
  mock_aurora.return_value.setup_database = mocker.Mock()
  mock_monitor = mocker.patch('src.sii_extraction.ExecutionMonitor')
  mock_monitor.return_value.init_execution = mocker.Mock()
  mock_aws = mocker.patch('src.sii_extraction.AWSClient')
  mock_aws.return_value.setup = mocker.Mock()

  mock_sii_ext.setup('config_file')

  df_result = mock_sii_ext.get_ter_data('01-2025')

  assert len(df_result) == 1