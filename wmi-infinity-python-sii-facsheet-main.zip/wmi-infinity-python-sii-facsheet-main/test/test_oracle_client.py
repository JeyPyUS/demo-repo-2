import pandas as pd

from src.oracle_client import OracleClient


mock_dict = {
  'db_user': 'db_user',
  'db_pass': 'db_pass',
  'db_server': 'db_server',
  'db_port': 'db_port',
  'db_name': 'db_name',
  'table_aux': 'table_aux'
}

mock_config_dict = {
  'oracle_db': mock_dict
}


def test_setup_database(mocker):

  mock_oracle = OracleClient(mocker.Mock(), 'test')

  mocker.patch('oracledb.connect', return_value='Connected')

  mock_oracle.setup_database(mock_config_dict)

  assert mock_oracle.connection == 'Connected'



def test_get_df(mocker):

  mock_df = pd.DataFrame({'a': [123]})

  mock_oracle = OracleClient(mocker.Mock(), 'test')

  mocker.patch('pandas.read_sql', return_value=mock_df)

  result_df = mock_oracle.get_df('query')

  pd.testing.assert_frame_equal(result_df, mock_df)