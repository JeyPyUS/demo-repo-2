import pandas as pd

from utils import mock_common_module
mock_common_module()
from src.aws_client import AWSClient


mock_dict = {
  'aws_s3_bucket': 'aws_s3_bucket',
  'aws_s3_prefix_output': 'aws_s3_prefix_output',
  'env': 'test'
}

mock_config_dict = {
  'aws_s3': mock_dict,
  'files_date': 'files_date'
}


def test_setup(mocker):

  mock_aws = AWSClient(mocker.Mock())

  mocker.patch('src.aws_client.AWSClient.get_aws_session', return_value='session')

  mock_aws.setup(mock_config_dict, 'monitor')

  assert mock_aws.s3_bucket == 'aws_s3_bucket'
  assert mock_aws.processed_folder == 'aws_s3_prefix_output'


def test_get_aws_session(mocker):

  mock_aws = AWSClient(mocker.Mock())

  mocker.patch('boto3.session.Session', return_value='session')
  mocker.patch('os.getenv', return_value='profile_name')
  mocker.patch('boto3.setup_default_session', side_effect=None)

  mock_session = mock_aws.get_aws_session()

  assert mock_session == 'session'


def test_send_df_to_s3(mocker):

  mock_aws = AWSClient(mocker.Mock())

  mock_df = pd.DataFrame({'a': [123]})

  mocker.patch('src.aws_client.AWSClient.get_aws_session', return_value='session')

  mock_aws.setup(mock_config_dict, mocker.Mock())
  result_send = mock_aws.send_df_to_s3(mock_df, 'query_name')

  assert result_send