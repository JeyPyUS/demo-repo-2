import pandas as pd

from src.redshift_client import RedshiftClient
from utils import mock_common_module
mock_common_module()


mock_dict = {
  'schema_dwh': 'schema_dwh',
  'table_performanceindex': 'table_performanceindex'
}

mock_redshift_dict = {
  'table_ter': 'table_ter',
  'schema_dwh': 'schema_dwh',
  'table_performanceindex': 'table_performanceindex'
}

mock_config_dict = {
  'redshift_db': mock_redshift_dict
}


def test_setup_tables(mocker):

  mock_redshift = RedshiftClient(mocker.Mock(), 'test')

  mock_redshift.setup_tables(mock_config_dict)

  assert mock_redshift.dwh == 'schema_dwh'
  assert mock_redshift.dwh_table_performance_index == 'table_performanceindex'