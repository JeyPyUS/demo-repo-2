import pytest
from src import main as m
import datetime

# Mocking of Common packages and modules
from utils import mock_common_module
mock_common_module()
from src.sii_extraction import SiiExtraction


def test_main(mocker):
    sii_extraction = SiiExtraction('Sii Extraction', mocker.Mock(), datetime.datetime.now())

    mocker.patch('src.sii_extraction.SiiExtraction.setup', side_effect=None)
    call_run = mocker.patch('src.sii_extraction.SiiExtraction.run', side_effect=None)

    m.main()

    call_run.assert_called_once()