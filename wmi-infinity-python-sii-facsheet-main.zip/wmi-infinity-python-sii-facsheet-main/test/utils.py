import sys
from typing import Union
from unittest.mock import Mock
import pandas as pd
from pandas import DataFrame
from pandasql import sqldf


class DatabaseClientMock(object):
  def __init__(self, logger, env):
    self.logger = logger
    self.env = env


def mock_common_module() -> Mock:
  mock_configpackage = Mock()
  mock_config = Mock()
  mock_common = Mock()
  mock_db = Mock()
  mock_db_utils = Mock()
  mock_db_executions = Mock()
  mock_db_client = Mock()
  mock_libs = Mock()
  mock_libs_s3_utils = Mock()
  mock_libs_logger_config = Mock()
  mock_db_client.DatabaseClient = DatabaseClientMock
  mock_configpackage.config = mock_config
  mock_common.Config = mock_configpackage
  mock_db.db_utils = mock_db_utils
  mock_db.db_executions = mock_db_executions
  mock_db.db_client = mock_db_client
  mock_libs.s3_utils = mock_libs_s3_utils
  mock_libs.logger = mock_libs_logger_config
  mock_common.DB = mock_db
  sys.modules['Common.Config.config'] = mock_config
  sys.modules['Common.Config'] = mock_configpackage
  sys.modules['Common.DB.db_utils'] = mock_db_utils
  sys.modules['Common.DB.db_executions'] = mock_db_executions
  sys.modules['Common.DB.database_client'] = mock_db_client
  sys.modules['Common.DB'] = mock_db
  sys.modules['Common.Libs.s3_utils'] = mock_libs_s3_utils
  sys.modules['Common.Libs.logger_configuration'] = mock_libs_logger_config
  sys.modules['Common.Libs'] = mock_libs
  sys.modules['Common'] = mock_common
  return mock_common


def get_dataframe_mock(query: str, df: DataFrame, table: str) -> DataFrame:
  result = sqldf(query.replace(table, 'df'))
  return result